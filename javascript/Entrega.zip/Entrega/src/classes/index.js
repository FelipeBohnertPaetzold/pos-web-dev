import Aluno from './Aluno'
import Curso from './Curso'

export { Aluno, Curso }
