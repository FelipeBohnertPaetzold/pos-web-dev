class Curso {
  constructor(nome, codigo, mediaAprovacao) {
    this.nome = nome
    this.codigo = codigo
    this.mediaAprovacao = mediaAprovacao
    this.quantidadeAlunos = 0
  }
}
